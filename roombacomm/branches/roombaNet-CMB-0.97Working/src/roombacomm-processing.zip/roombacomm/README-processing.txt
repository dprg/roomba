#
# Note that this specifies the RXTX library and accompanying native libs.
# This may cause a problem if the 'Serial' library is also used
#
#
